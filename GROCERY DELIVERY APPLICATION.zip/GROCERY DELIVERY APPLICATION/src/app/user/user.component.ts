import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
//public userDetails;
  constructor( private router:Router) { }

  ngOnInit(): void {
// const storage =localStorage.getItem('google_auth');
// if(storage){
//   this.userDetails=JSON.parse(storage);
// }else{
// this.signout();
// }
  }
signout():void{
  localStorage.removeItem('google_auth');
  this.router.navigateByUrl('/login').then();
}

  

}

