import { GoogleLoginProvider, SocialAuthService } from '@abacritt/angularx-social-login';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, Routes } from '@angular/router';
import { AdminComponent } from '../admin/admin.component';
import { UserComponent } from '../user/user.component';
import { UserAuthService } from '../_services/user-auth.service';
import { UserService } from '../_services/user.service';
// const routes:Routes=[
//   {
//     path:'',
//     redirectTo:'login',
//     pathMatch:'full'
//   },
//   {
//     path:'user',
//     component: UserComponent
//   },
// ]
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private userService: UserService, private  userAuthService:UserAuthService
   , private router:Router ,private authService:SocialAuthService)
     { }

  ngOnInit(): void {
  } 
  signInGoogleHandler():void{
   this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then((data)=>
 {    localStorage.setItem('google_auth',JSON.stringify(data));
    this.router.navigateByUrl('/user').then();
    });
 }
   login(loginForm:NgForm){
  this.userService.login(loginForm.value).subscribe(
    (response:any)=>{
      // console.log(response.jwtToken);
      // console.log(response.user.role);
    this.userAuthService.setRoles(response.user.role);
    this.userAuthService.setToken(response.jwtToken);
    console.log(response);
     const role=response.user.role[0].roleName;
    if(role === 'Admin'){
      this.router.navigate(['/admin']);

    } else{
      this.router.navigate(['/user']);
    }
  },
    (error)=>{
      console.log(error);
    }
  );
 
  }
}
