import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  constructor() { }
  public setRoles(roles:[]){
    window.localStorage.setItem('roles',JSON.stringify(roles));
  }
  public getRoles():[]{
    return JSON.parse(window.localStorage.getItem('roles'));
  }
  public setToken(jwtToken:string){
   window.localStorage.setItem('jwtToken',jwtToken);
  }
  public getToken():string{
    return window.localStorage.getItem('jwtToken');
  }
  public clear(){
   window.localStorage.clear();
  }
  public isLoggedIn(){
    return this.getRoles() && this.getToken();
    
}
}